﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nPara calcular a Area de Terreno [Metro Quadrado] - Terreno de Tamanho Regular [4 lados iguais] - iremos calcular a largura vezes o comprimento."
                + "\nPara calcular o Perimetro de Terreno [Metro Corrido] - Terreno de Tamanho Regular [4 lados iguais] - iremos somar todos os lados e obter o metro corrido."
                + "\nPara calcular a Area de Imovel [Metro Quadrado] - Terreno de Tamanho Regular [4 lados iguais] - iremos calcular a largura vezes o comprimento."
                + "\nPara calcular o Perimetro de Imovel [Metro Corrido] - Terreno de Tamanho Regular [4 lados iguais] - iremos somar todos os lados e obter o metro corrido."
                + "\nPara calcular a Area de Muro ou Parede [Metro Quadrado] - Muro ou Parede de Tamanho Regular [4 lados iguais] - iremos calcular a altura vezes a largura."
                + "\nPara calcular a Area de Casa Edificada [Alvenaria - Metro Quadrado] - Paredes de Tamanho Regular [4 lados iguais] - iremos calcular os metros quadrados de uma parede vezes a quantidade de lados da casa."
                + "\nPara calcular a Area de Comodo Edificado [Alvenaria - Metro Quadrado] - Parede de Tamanho Regular [4 lados iguais] - iremos calcular os metros quadrados de uma parede vezes a quantidade de lados do comodo."
                + "\nPara calcular a quantidade de blocos de alvenaria para construir um muro ou parede, iremos calcular os metros quadrados de uma parede vezes 25 que equivale a um metro quadrado com 25 blocos de alvenaria.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Text = "Sobre";
            MessageBox.Show("Sobre\n" + "\nSoftware: Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil \n" + "\nAuthor: PHNO" + "\nData Release: 03/09/2024" + "\nVersao Codigo: 0.0.0.4v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");

        }

        private void button3_Click(object sender, EventArgs e) // Area de Terreno [Metro Quadrado]
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                int mult = numero1 * numero2;

                textBox3.Text = ("" + mult);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
            

        }

        private void button4_Click(object sender, EventArgs e) // Perimetro de Terreno [Metro Corrido]
        {
            if (int.TryParse(textBox4.Text, out int numero3) && int.TryParse(textBox5.Text, out int numero4))
            {
                int numero5 = 2;
                int mult2 = numero3 + numero4;
                int result = mult2 * numero5;

                textBox6.Text = ("" + result);
            }
            else
            {
                textBox6.Text = "Erro. digite um numero.";
            }

        }

        private void button5_Click(object sender, EventArgs e) // Area de Imovel [Metro Quadrado]
        {
            if (int.TryParse(textBox7.Text, out int numero6) && int.TryParse(textBox8.Text, out int numero7))
            {
                int mult3 = numero6 * numero7;

                textBox9.Text = ("" + mult3);
            }
            else
            {
                textBox9.Text = "Erro. digite um numero.";
            }
        }

        private void button6_Click(object sender, EventArgs e) // Perimetro de Imovel [Metro Corrido]
        {
            if (int.TryParse(textBox10.Text, out int numero8) && int.TryParse(textBox11.Text, out int numero9))
            {
                int numero10 = 2;
                int mult4 = numero8 + numero9;
                int result2 = mult4 * numero10;

                textBox12.Text = ("" + result2);
            }
            else
            {
                textBox12.Text = "Erro. digite um numero.";
            }
        }

        private void button7_Click(object sender, EventArgs e) // Area de Muro ou Parede [Metro Quadrado]
        {
            if (int.TryParse(textBox13.Text, out int numero11) && int.TryParse(textBox14.Text, out int numero12))
            {
                int numero13 = 25;
                int result3 = numero11 * numero12;
                int result4 = result3 * numero13;

                textBox15.Text = ("" + result3);
                textBox20.Text = ("" + result4);
            }
            else
            {
                textBox15.Text = "Erro. digite um numero.";
                textBox20.Text = "Erro. digite um numero.";
            }
        }

        private void button8_Click(object sender, EventArgs e) // Area de Casa Edificada [Alvenaria - Metro Quadrado]
        {
            if (int.TryParse(textBox16.Text, out int numero14) && int.TryParse(textBox17.Text, out int numero15))
            {
                int numero16 = 25;
                int result5 = numero14 * numero15;
                int result6 = result5 * numero16;

                textBox18.Text = ("" + result5);
                textBox19.Text = ("" + result6);
            }
            else
            {
                textBox18.Text = "Erro. digite um numero.";
                textBox19.Text = "Erro. digite um numero.";
            }
        }

        private void button9_Click(object sender, EventArgs e) // Area de Comodo Edificado [Alvenaria - Metro Quadrado]
        {
            if (int.TryParse(textBox21.Text, out int numero17) && int.TryParse(textBox22.Text, out int numero18))
            {
                int numero19 = 25;
                int result7 = numero17 * numero18;
                int result8 = result7 * numero19;

                textBox23.Text = ("" + result7);
                textBox24.Text = ("" + result8);
            }
            else
            {
                textBox23.Text = "Erro. digite um numero.";
                textBox24.Text = "Erro. digite um numero.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // chama metodo limpar
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
                textBox20.Clear();
                textBox21.Clear();
                textBox22.Clear();
                textBox23.Clear();
                textBox24.Clear();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // chama metodo limpar
            }
            else
            {
                textBox3.Text = "Erro. nada para apagar.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero3) && int.TryParse(textBox5.Text, out int numero4))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear(); // chama metodo limpar
            }
            else
            {
                textBox6.Text = "Erro. nada para apagar.";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero6) && int.TryParse(textBox8.Text, out int numero7))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear(); // chama metodo limpar
            }
            else
            {
                textBox9.Text = "Erro. nada para apagar.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox10.Text, out int numero8) && int.TryParse(textBox11.Text, out int numero9))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox10.Clear();
                textBox11.Clear();
                textBox12.Clear(); // chama metodo limpar
            }
            else
            {
                textBox12.Text = "Erro. nada para apagar.";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox13.Text, out int numero11) && int.TryParse(textBox14.Text, out int numero12))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear(); // chama metodo limpar
                textBox20.Clear();
            }
            else
            {
                textBox15.Text = "Erro. nada para apagar.";
                textBox20.Text = "Erro. nada para apagar.";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int numero14) && int.TryParse(textBox17.Text, out int numero15))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear(); // chama metodo limpar
                textBox19.Clear();
            }
            else
            {
                textBox18.Text = "Erro. nada para apagar.";
                textBox19.Text = "Erro. nada para apagar.";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox21.Text, out int numero17) && int.TryParse(textBox22.Text, out int numero18))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.4v - Calculo para Engenharia Civil";
                textBox21.Clear(); // chama metodo limpar
                textBox22.Clear();
                textBox23.Clear();
                textBox24.Clear();
            }
            else
            {
                textBox23.Text = "Erro. nada para apagar.";
                textBox24.Text = "Erro. nada para apagar.";
            }
        }
    }
}
